package com.interviewbit.practiseNew;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

public class InterviewBitStacksAndQueues {

	public static ArrayList<Integer> slidingMaximum(final List<Integer> A, int B) {
		ArrayList<Integer> list = new ArrayList<>();
		Queue<Integer> queue = new LinkedList<>();
		int i = 0;
		while (i < B) {
			while (!queue.isEmpty() && A.get(i) > A.get(queue.peek())) {
				queue.poll();
			}
			queue.add(i);
			i++;
		}
		while (i < A.size()) {
			// System.out.print(queue.poll());
			list.add(A.get(queue.peek()));
			while (!queue.isEmpty() && queue.peek() <=i - B) {
				queue.poll();
			}
			while (!queue.isEmpty() && A.get(i) > A.get(queue.peek())) {
				queue.poll();
			}
			queue.add(i);
			i++;
		}
		if (!queue.isEmpty()) {
			list.add(A.get(queue.peek()));
		}
		return list;
	}

	public static void main(String[] args) {
		List<Integer> A = new ArrayList<>();
		A.add(10);
		A.add(9);
		A.add(8);
		A.add(7);
		A.add(6);
		A.add(5);
		A.add(4);
		A.add(3);A.add(2);A.add(1);
		slidingMaximum(A, 2);
	}

}
