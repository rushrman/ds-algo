package com.interviewbit.practiseNew;

import java.util.ArrayList;
import java.util.Collections;

public class TwoPointers {
	public int threeSumClosest(ArrayList<Integer> A, int B) {
		Collections.sort(A);
		int diff = Integer.MAX_VALUE;
		for (int i = 0; i < A.size() - 3; i++) {
			int l = i + 1;
			int r = A.size() - 1;
			while (l < r) {
				if (Math.abs(A.get(i) + A.get(l) + A.get(r) - B) <= diff) {
					diff = Math.abs(A.get(i) + A.get(l) + A.get(r));
				}
				if (A.get(i) + A.get(l) + A.get(r) > B) {
					r--;
				} else {
					l++;
				}
			}
		}
		return diff;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
}
