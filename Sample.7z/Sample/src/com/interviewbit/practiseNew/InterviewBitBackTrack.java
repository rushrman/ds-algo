package com.interviewbit.practiseNew;

public class InterviewBitBackTrack {

	// public ArrayList<ArrayList<Integer>> permute(ArrayList<Integer> A) {
	//
	// }
	static int x = 0;

	static void printPermute(String input, String ans, int k) {
		if (input.equals("")) {
			System.out.println(ans);
			x++;
			if (x == k) {
				System.exit(0);
				return;
			}
		} else {
			for (int i = 0; i < input.length(); i++) {
				char c = input.charAt(i);
				String res = input.substring(0, i) + input.substring(i + 1);
				printPermute(res, ans + c, k);
			}
		}
	}

	public static void main(String[] args) {
		printPermute("abc", "", 5);
	}

}
