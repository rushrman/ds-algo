/**
 * 
 */
package com.interviewbit.practiseNew;

/**
 * @author RushabhkumarKhandare
 *
 */
class SampleClass {

	/**
	 * 
	 */
	public SampleClass() {
		// TODO Auto-generated constructor stub
	}

	void getMethod() {
		System.out.println("i am sample class method");
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
