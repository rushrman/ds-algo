package com.interviewbit.practiseNew;

import java.util.ArrayList;
import java.util.Arrays;

public class InterviwBitBinarySearch {
	static int getMax(int[] arr, int n) {
		int max = arr[0];
		for (int i = 1; i < n; i++) {
			if (max < arr[i]) {
				max = arr[i];
			}
		}
		return max;
	}

	static int getSum(int[] arr, int n) {
		int total = 0;
		for (int i = 0; i < n; i++) {
			total += arr[i];
		}
		return total;
	}

	static int getNumberOfrequired(int[] arr, int n, int mid) {
		int numberOFrecord = 0;
		int total = 0;
		for (int i = 0; i < n; i++) {
			total += arr[i];
			if (total > mid) {
				total = arr[i];
				numberOFrecord++;
			}
		}
		return numberOFrecord;
	}

	static int getPartionsSum(int[] arr, int n, int k) {
		int lo = getMax(arr, n);
		int hi = getSum(arr, n);
		int mid;
		while (lo < hi) {
			mid = lo + (hi - lo) / 2;
			int numberOfRequired = getNumberOfrequired(arr, n, mid);
			if (numberOfRequired <= k) {
				hi = mid;
			} else {
				lo = mid + 1;
			}
		}
		return lo;
	}

	public int paint(int A, int B, ArrayList<Integer> C) {
		int[] a = new int[C.size()];
		for (int i = 0; i < C.size(); i++) {
			a[i] = C.get(i);
		}
		return getPartionsSum(a, a.length, A)*B;
	}

	public static void main(String args[]) {

	}
}
