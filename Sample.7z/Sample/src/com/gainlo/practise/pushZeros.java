/**
 * 
 */
package com.gainlo.practise;

/**
 * @author RushabhkumarKhandare
 *
 */
public class pushZeros {

	public static void pushZeroAtlast(int[] arr) {
		int count = 0;
		for (int i = 0; i < arr.length; i++) {
			if (arr[i] != 0) {
				arr[count++] = arr[i];
			}
		}
		while (count < arr.length) {
			arr[count++] = 0;
		}
		for(int i=0;i<arr.length;i++){
			System.out.print(arr[i]+" ");
		}
	}

	public static void main(String[] args) {
		int arr[] = {1,5,0,2,8,0,6,3,9,0,10,0,13,0};
		pushZeroAtlast(arr);
	}

}
