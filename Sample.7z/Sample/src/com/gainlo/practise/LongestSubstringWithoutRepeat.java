package com.gainlo.practise;

import java.util.Arrays;

public class LongestSubstringWithoutRepeat {
	public static int longestSubstringNonRepeat(String input) {
		int prevIndex = -1;
		int curr_len = 1;
		int max_len = 1;
		int[] visited = new int[256];
		Arrays.fill(visited, -1);
		visited[input.charAt(0)] = 0;
		for (int i = 1; i < input.length(); i++) {
			prevIndex = visited[input.charAt(i)];
			if (prevIndex == -1 || prevIndex < curr_len - i) {
				curr_len++;
			} else {
				if (max_len < curr_len) {
					max_len = curr_len;
				}
				curr_len = i - prevIndex;
			}
			visited[input.charAt(i)] = i;
		}
		if (max_len < curr_len) {
			max_len = curr_len;
		}
		return max_len;

	}

	public static void main(String args[]) {
		System.out.println(longestSubstringNonRepeat("ABDEFGABEF"));
	}

}
