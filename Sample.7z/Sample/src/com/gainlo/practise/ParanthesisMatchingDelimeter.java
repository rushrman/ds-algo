/**
 * 
 */
package com.gainlo.practise;

import java.util.Stack;

/**
 * @author RushabhkumarKhandare
 *
 */
public class ParanthesisMatchingDelimeter {
	private static boolean isMatching(Character char1, Character char2) {
		if (char1 == '{' && char2 == '}') {
			return true;
		} else if (char1 == '[' && char2 == ']') {
			return true;
		} else if (char1 == '(' && char2 == ')') {
			return true;
		} else {
			return false;
		}
	}

	public static boolean paranthesisMatching(String input) {
		Stack<Character> stack = new Stack<>();
		for (int i = 0; i < input.length(); i++) {
			char c = input.charAt(i);
			if (c == '{' || c == '[' || c == '(') {
				stack.push(c);
			}
			if (c == '}' || c == ']' || c == ')') {
				if (stack.isEmpty()) {
					return false;
				}
				if (!isMatching(stack.pop(), input.charAt(i))) {
					return false;
				}
			}
		}
		if (stack.isEmpty()) {
			return true;
		} else {
			return false;
		}
	}

	public static void main(String[] args) {
		System.out.println(paranthesisMatching("{3234[fd"));

	}

}
