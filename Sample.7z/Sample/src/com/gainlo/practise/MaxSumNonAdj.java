package com.gainlo.practise;

public class MaxSumNonAdj {
	/*
	 * DP Solution
	 */
	public static int maxSumNonAdjDp(int[] arr) {
		int incl = arr[0];
		int excl = 0;
		int temp = 0;
		for (int i = 1; i < arr.length; i++) {
			temp = incl;
			incl = Math.max(excl + arr[i], incl);
			excl = temp;
		}
		return incl;
	}

	/*
	 * Recursive solution
	 */
	public static int maxSumNonAdj(int[] arr, int index) {
		if (index == 0) {
			return arr[index];
		} else if (index == 1) {
			return Math.max(arr[0], arr[1]);
		}
		return Math.max(maxSumNonAdj(arr, index - 2) + arr[index], maxSumNonAdj(arr, index - 1));

	}

	public static void main(String args[]) {
		int arr[] = { 2, 10, 13, 4, 2, 15, 10 };
		System.out.println(maxSumNonAdjDp(arr));
	}

}
