package com.gainlo.practise;

public class LongestRepeatNOverlapSubString {

	public static String longestRepeatingAndNonOverlapping(String input) {
		int n = input.length();
		int[][] LRNO = new int[n + 1][n + 1];
		String res = "";
		int res_length = 0;
		int i, index = 0;
		for (i = 1; i <= n; i++) {
			for (int j = i + 1; j <= n; j++) {
				if (input.charAt(i - 1) == input.charAt(j - 1) && j - i > LRNO[i - 1][j - 1]) {
					LRNO[i][j] = LRNO[i - 1][j - 1] + 1;
					if (res_length < LRNO[i][j]) {
						res_length = LRNO[i][j];
						index = Math.max(i, index);
					}
				} else {
					LRNO[i][j] = 0;
				}
			}
		}
		for (i = index - res_length + 1; i <= index; i++) {
			res = res + input.charAt(i - 1);
		}
		return res;
	}

	public static void main(String args[]) {
		System.out.println(longestRepeatingAndNonOverlapping("geeksforgeeks"));
	}
}
