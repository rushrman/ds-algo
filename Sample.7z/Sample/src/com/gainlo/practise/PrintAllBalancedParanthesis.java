/**
 * 
 */
package com.gainlo.practise;

/**
 * @author RushabhkumarKhandare
 *
 */
public class PrintAllBalancedParanthesis {

	public static void printAllBalancedParenthesis(char[] str, int n) {
		if (n > 0)
			printAllBalancedParenthesisUtil(str, 0, n, 0, 0);
		return;
	}

	/*
	 * IF open is greater than close add { else add } If close equals to n print
	 * the array
	 */
	private static void printAllBalancedParenthesisUtil(char[] str, int pos, int n, int open, int close) {
		if (close == n) {
			for (int i = 0; i < str.length; i++) {
				System.out.print(str[i]);
			}
			System.out.println();
			return;
		} else {
			if (open > close) {
				str[pos] = '}';
				printAllBalancedParenthesisUtil(str, pos + 1, n, open, close+1);
			} 
			if (open < n) {
				str[pos] = '{';
				printAllBalancedParenthesisUtil(str, pos + 1, n, open+1, close);
			}
		}
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int n = 3;
		char[] str = new char[2 * n];
		printAllBalancedParenthesis(str, n);
	}

}
