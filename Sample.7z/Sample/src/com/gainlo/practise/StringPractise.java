/**
 * 
 */
package com.gainlo.practise;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

/**
 * @author RushabhkumarKhandare another approach is to use isSubsequence method
 *         to check that it is present as subsequence or not
 */
public class StringPractise {

	public static String findLargestWordBydeletingSomeChar(String[] dictionary, String find) {
		Map<Character, Integer> findmap = new HashMap<>();
		for (int i = 0; i < find.length(); i++) {
			if (findmap.containsKey(find.charAt(i))) {
				findmap.put(find.charAt(i), findmap.get(find.charAt(i)) + 1);
			} else {
				findmap.put(find.charAt(i), 1);
			}
		}
		String currres = "";
		String maxres = "";
		boolean found = false;
		for (int i = 0; i < dictionary.length; i++) {
			String dict = dictionary[i];
			currres = dict;
			for (int j = 0; j < dict.length(); j++) {
				if (findmap.containsKey(dict.charAt(j))) {
					found = true;
				} else {
					found = false;
					break;
				}
			}
			if (found && maxres.length() < currres.length()) {
				maxres = currres;
			}
		}
		return maxres;
	}

	/*
	 * K unique characters from the string
	 */
	public static String getKuniques(String str, int k) {
		int count[] = new int[256];
		int u = 0;
		for (int i = 0; i < str.length(); i++) {
			if (count[str.charAt(i) - 'a'] == 0) {
				u++;
			}
			count[str.charAt(i) - 'a']++;
		}
		if (u < k) {
			System.out.print("not enough");
			return "";
		}
		int curr_start = 0, curr_end = 0;
		int max_window_size = 1, max_window_start = 0;
		Arrays.fill(count, 0);
		count[str.charAt(0) - 'a']++;
		for (int i = 1; i < str.length(); i++) {
			count[str.charAt(i) - 'a']++;
			curr_end++;
			while (!isValid(count, k)) {
				count[str.charAt(i) - 'a']--;
				curr_start++;
			}
			if (curr_end - curr_start + 1 > max_window_size) {
				max_window_size = curr_end - curr_start + 1;
				max_window_start = curr_start;
			}
		}
		return str.substring(max_window_start, max_window_size - 1);
	}

	private static boolean isValid(int[] count, int k) {
		int val = 0;
		for (int i = 0; i < count.length; i++) {
			if (count[i] > 0) {
				val++;
			}
		}
		return (k >= val);
	}
	
	public static void main(String[] args) {
		String[] input = { "ale", "apple", "monkey", "plea" };

		System.out.println(findLargestWordBydeletingSomeChar(input, "abpcplea"));

	}

}
