/**
 * 
 */
package com.interview.bit;

/**
 * @author RushabhkumarKhandare
 *
 */
public class RodCutting {
	public static int cutRodRec(int[] a, int n) {
		if (n <= 0)
			return 0;
		int max = Integer.MIN_VALUE;
		for (int i = 0; i < n; i++) {
			max = Math.max(max, a[i] + cutRodRec(a, n - i - 1));
		}
		return max;
	}

	public static int cutRodDp(int[] a, int n) {
		int[] val = new int[n + 1];
		val[0] = 0;
		for (int i = 1; i <= n; i++) {
			int max = Integer.MIN_VALUE;
			for (int j = 0; j < i; j++) {
				max = Math.max(max, a[j] + val[i - j - 1]);
			}
			val[i] = max;
		}
		return val[n];
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
