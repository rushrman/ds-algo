/**
 * 
 */
package com.interview.bit;

import java.util.Stack;

/**
 * @author RushabhkumarKhandare
 *
 */
public class LongValidPar {
	 public static int longestValidParentheses(String A) {
		 Stack<Integer> stk = new Stack<>();
		 stk.add(-1);
		 int n = A.length();
		 int result =0;
		 for(int i=0;i<n;i++){
			 if(A.charAt(i)=='(')
				stk.push(i);
			 else{
				 stk.pop();
				 if(!stk.isEmpty())
					 result=Math.max(result, i-stk.peek());
				 else stk.push(i);
			 }
		 }
		return result;
	    }
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		System.out.println(longestValidParentheses(")()())"));

	}

}
