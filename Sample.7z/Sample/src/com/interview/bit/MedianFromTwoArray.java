package com.interview.bit;

import java.util.ArrayList;
import java.util.List;

public class MedianFromTwoArray {
	// DO NOT MODIFY BOTH THE LISTS
	public static double findMedianSortedArrays(final List<Integer> a, final List<Integer> b) {
		double result = 0.0;
		if (a == null || a.size() == 0)
			return getMedian(b);
		else if (b == null || b.size() == 0) {
			return getMedian(a);
		}
		result = findMedianSortedUtil(a, b, 0, a.size() - 1, 0, b.size() - 1);
		return result;
	}

	private static double getMedian(List<Integer> a) {
		if (a.size() > 0 && a.size() % 2 == 0) {
			return (a.get(a.size() / 2) + a.get(a.size() / 2 - 1)) / 2.0;
		} else if (a.size() > 0) {
			return a.get(a.size() / 2);
		}
		return 0;
	}

	private static double findMedianSortedUtil(List<Integer> a, List<Integer> b, int i, int j, int k, int l) {
		if ((j - i == 0) && (l - k == 0)) {
			return (a.get(0)+b.get(0))/2;
		}
		
		if ((j - i == 1) && (l - k == 1)) {
			return (1.0 * (Math.max(a.get(i), b.get(j)) + Math.min(a.get(j), b.get(l))) / 2);
		}
		int m1_index = (i + j) / 2;
		int m2_index = (k + l) / 2;
		int m1 = a.get(m1_index);
		int m2 = b.get(m2_index);
		if (m1 == m2)
			return m2;
		if (m1 < m2) {
			i = m1_index;
			l = m2_index;
		} else {
			k = m2_index;
			j = m1_index;
		}
		return findMedianSortedUtil(a, b, i, j, k, l);
	}

	public static void main(String srgs[]) {
		List<Integer> a = new ArrayList<>();
		List<Integer> b = new ArrayList<>();
		a.add(-50);
		a.add(-41);
		a.add(-40); a.add(-19);a.add(5);a.add(21);a.add(28);//a.add(48);
		b.add(-50);
		b.add(-21); b.add(-10);//b.add(-6);b.add(1);b.add(8);
		System.out.println(findMedianSortedArrays(a, b));
	}
}
