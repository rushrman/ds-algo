package com.interview.bit;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

public class GraphQuestions {
	public int solve(int A, ArrayList<Integer> B, ArrayList<Integer> C) {
		Graph g = new Graph(A);
		int[] indegree = new int[A];
		for (int i = 0; i < B.size(); i++) {
			g.addEdge(C.get(i)-1, B.get(i)-1);
		}
		// calculate indegrees
		for (int i = 0; i < g.V; i++) {
			ArrayList<Integer> a = (ArrayList<Integer>) g.adj[i];
			for (int node : a) {
				indegree[node]++;
			}
		}
		// add zero degree to Queue
		Queue<Integer> queue = new LinkedList<Integer>();
		for (int i = 0; i < g.V; i++) {
			if (indegree[i] == 0) {
				queue.add(i);
			}
		}
		List<Integer> topOrder = new ArrayList<>();
		int count = 0;
		while (!queue.isEmpty()) {
			int top = queue.poll();
			topOrder.add(top);
			Iterator<Integer> it = g.adj[top].iterator();
			while (it.hasNext()) {
				int x = it.next();
				if (--indegree[x] == 0) {
					queue.add(x);
				}
			}
			count++;

		}
		if (count != A) {
			return 0;
		}
		return 1;
	}

	public static void main(String args[]) {
		ArrayList<Integer> l1 = new ArrayList<>();
		l1.add(1);
		l1.add(2);
		ArrayList<Integer> l2 = new ArrayList<>();
		l2.add(2);
		l2.add(3);
		GraphQuestions gq = new GraphQuestions();
		System.out.println(gq.solve(3, l1, l2));
	}
}

class Graph {
	int V;
	List<Integer>[] adj;

	Graph(int v) {
		this.V = v;
		adj = new List[V];
		for (int i = 0; i < V; i++) {
			adj[i] = new ArrayList<>();
		}
	}

	public void addEdge(int u, int v) {
		adj[u].add(v);
	}
}
