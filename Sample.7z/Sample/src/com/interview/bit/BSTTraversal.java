package com.interview.bit;

import java.util.ArrayList;
import java.util.List;

class Node {
	int value;
	Node left;
	Node right;

	Node(int data) {
		value = data;
		left = right = null;
	}
}

class DBNode {
	List<Integer> nodeList;
	DBNode prev;
	DBNode next;

	public DBNode() {
		nodeList = new ArrayList<>();
		prev = next = null;
	}
}

public class BSTTraversal {
	void printVerticalUtil(Node root, DBNode dbroot) {
		dbroot.nodeList.add(root.value);
		if (root.left != null) {
			if (dbroot.prev == null) {
				dbroot.prev = new DBNode();
				dbroot.prev.next = dbroot;
			}
			printVerticalUtil(root.left, dbroot.prev);
		}
		if (root.right != null) {
			if (dbroot.next == null) {
				dbroot.next = new DBNode();
				dbroot.next.prev = dbroot;
			}
			printVerticalUtil(root.right, dbroot.prev);
		}
	}

	void printVertical(Node root) {
		DBNode dbroot = new DBNode();
		printVerticalUtil(root, dbroot);
		printDB(dbroot);
	}

	private void printDB(DBNode dbroot) {
		while (dbroot.prev != null)
			dbroot = dbroot.prev;
		while (dbroot.next != null){
			System.out.println(dbroot.nodeList);
			dbroot=dbroot.next;
		}
	}

	public static void main(String args[]) {
		Node root = new Node(6);
		root.left = new Node(7);
		root.right = new Node(8);
		root.left.left = new Node(5);
		root.left.right = new Node(4);
		root.right.right = new Node(1);
		root.right.left = new Node(2);
		BSTTraversal bstTraverse = new BSTTraversal();
		bstTraverse.printVertical(root);
	}
}
