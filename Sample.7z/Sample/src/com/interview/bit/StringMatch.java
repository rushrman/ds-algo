/**
 * 
 */
package com.interview.bit;

import java.util.Arrays;

/**
 * @author RushabhkumarKhandare
 *
 */
public class StringMatch {
	/*
	 * @param
	 */
	public static int isMatch(final String A, final String B) {
		int m = A.length();
		int n = B.length();
		if (n == 0 && m == 0)
			return 1;
		boolean[][] PM = new boolean[m + 1][n + 1];
		for (int i = 0; i < m; i++)
		Arrays.fill(PM[i], false);
		PM[0][0] = true;
		for (int i = 1; i <= n; i++) {
			if (B.charAt(i - 1) == '*')
				PM[0][i] = PM[0][i-1];
		}
		for (int i = 1; i <= m; i++) {
			for (int j = 1; j <= n; j++) {
				if (B.charAt(j - 1) == '*') {
					PM[i][j] = PM[i][j - 1] || PM[i - 1][j];
				} else if (A.charAt(i - 1) == B.charAt(j - 1) || B.charAt(j - 1) == '?') {
					PM[i][j] = PM[i - 1][j - 1];
				} else
					PM[i][j] = false;
			}
		}
		if (PM[m][n])
			return 1;
		else
			return 0;
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		System.out.println(isMatch("bcaccbabaa", "bb*c?c*?"));

	}

}
