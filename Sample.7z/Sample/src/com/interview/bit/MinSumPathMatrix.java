/**
 * 
 */
package com.interview.bit;

import java.util.ArrayList;

/**
 * @author RushabhkumarKhandare
 *
 */
public class MinSumPathMatrix {
	public static int minPathSum(ArrayList<ArrayList<Integer>> A) {
		if(A.size()==1&&A.get(0).size()==1)
			return A.get(0).get(0);
		return minCost(A, A.size(), A.get(0).size());
	}

	static int minCost(ArrayList<ArrayList<Integer>> A, int m, int n) {
		if(m<0||n<0)
			return Integer.MAX_VALUE;
		else if(m==0&&n==0)
			return A.get(m).get(n);
		else return A.get(m).get(n)+min(minCost(A,m-1,n-1),minCost(A,m,n-1),minCost(A,m-1,n));
	}

	static int min(int x, int y, int z) 
    { 
        if (x < y) 
            return (x < z) ? x : z; 
        else
            return (y < z) ? y : z; 
    }  

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
