package com.interview.bit;

import java.util.ArrayList;
import java.util.List;

public class ArraysInterviewBit {
	public ArrayList<Integer> repeatedNumber(final List<Integer> A) {
		ArrayList<Integer> res = new ArrayList<>();
		int repeatNum = 0;
		int missingNum = 0;
		int sum = 0;
		boolean[] a = new boolean[A.size()];
		for (int i = 0; i < A.size(); i++) {
			int currNum = A.get(i);
			sum += currNum;
			if (a[currNum]) {
				repeatNum = currNum;
			} else {
				a[currNum] = true;
			}
		}
		int actualSum = A.size()-1 * (A.size() - 2) / 2;
		if (repeatNum != 0) {
			sum -= repeatNum;
			missingNum = actualSum - sum;
			res.add(repeatNum);
			res.add(missingNum);
		}
		return res;
	}

	public static void main(String args[]) {

	}
}
