/**
 * 
 */
package com.interview.bit;

import java.util.ArrayList;
import java.util.HashSet;

/**
 * @author RushabhkumarKhandare
 *
 */
public class SuperString {
	/*public int solve(ArrayList<String> A) {
		HashSet<Character> str = new HashSet<>();
	}*/

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
