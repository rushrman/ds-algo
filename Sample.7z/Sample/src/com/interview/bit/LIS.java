package com.interview.bit;

import java.util.ArrayList;
import java.util.List;

public class LIS {
	// DO NOT MODIFY THE LIST. IT IS READ ONLY
	public static int lis(final List<Integer> A) {
		int[] LIS = new int[A.size()];
		List<Integer> B = new ArrayList<>();
		for (int i = 0; i < LIS.length; i++)
			LIS[i] = 1;
		for (int i = 1; i < LIS.length; i++)
			for (int j = 0; j < i; j++) {
				if (A.get(i) > A.get(j) && (A.get(i) + A.get(j)) % 2 != 0 && LIS[i] < LIS[j] + 1) {
					LIS[i] = LIS[j] + 1;
				}
			}
		int result = 0;
		for (int j = 0; j < LIS.length; j++)
			result = Math.max(result, LIS[j]);
		int temp = result;
		for (int j = LIS.length - 1; j >= 0; j--) {
			if (LIS[j] == temp) {
				B.add(j);
				--temp;
			}
		}
		System.out.println(B);
		return result;
	}

	public static int lisWithBS(int[] nums) {
		ArrayList<Integer> lis = new ArrayList<>();
		for (int num : nums) {
			if (lis.size() == 0 || num > lis.get(lis.size() - 1))
				lis.add(num);
			else {
				int i = 0;
				int j = lis.size() - 1;
				while (i < j) {
					int mid = (i + j) / 2;
					if (lis.get(mid) < num)
						i = mid + 1;
					else
						j = mid;
				}
				lis.set(j, num);
			}
		}
		System.out.println("LIS "+lis);
		return lis.size();
	}

	public static void main(String args[]) {
		List<Integer> A = new ArrayList<>();
		A.add(0);
		A.add(8);
		A.add(4);
		A.add(12);
		A.add(2);
		A.add(10);
		A.add(6);
		A.add(14);
		A.add(1);
		A.add(9);
		A.add(5);
		A.add(13);
		A.add(3);
		A.add(11);
		A.add(7);
		A.add(15);
		// 1, 12, 2, 22, 5, 30, 31, 14, 17, 11
		// A.add(1);A.add(12);A.add(2);A.add(22);A.add(5);A.add(30);A.add(31);A.add(14);A.add(17);A.add(11);
		// 1, 12, 2, 22, 5, 30, 31, 14, 17, 11
		A.add(1);
		A.add(12);
		A.add(2);
		A.add(22);
		A.add(5);
		A.add(30);
		A.add(31);
		A.add(14);
		A.add(17);
		A.add(11);
		int[] a = { 10, 22, 9, 33, 21, 50, 41, 60 };
		System.out.println(lisWithBS(a));
	}
}
