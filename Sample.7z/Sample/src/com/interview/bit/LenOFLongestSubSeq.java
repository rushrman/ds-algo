/**
 * 
 */
package com.interview.bit;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/**
 * @author RushabhkumarKhandare
 *
 */
public class LenOFLongestSubSeq {
	
	static int LISutil(List<Integer> a, int l,int r){
		int n = r-l;
		int [] LIS = new int[n];
		for(int i =0;i<r;i++)
			LIS[i]=1;
		for(int i =1;i<r;i++){
			for(int j=0;j<i;j++){
				if(a.indexOf(j)<a.indexOf(i)&&LIS[i]<LIS[j]+1)
					LIS[i]=LIS[j]+1;
			}
		}
		int res=0;
		for(int i =0;i<r;i++){
			if(res<LIS[i])
				res=LIS[i];
		}
		return res;
	}
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int [] a = {1,11,2,10,4,5,2,1};
		List<Integer> A = new ArrayList<>();
		
		for(int  i=0;i<a.length;i++)
		A.add(a[i]);
		List<Integer> B = new ArrayList<>();
		Collections.copy(B, A);
		int result=0;
		result+=LIS(A,0,A.size());
		Collections.reverse(A);
		result+=LIS(A,0,A.size());
		System.out.println(result);

	}
	private static int LIS(List<Integer> a, int i, int j) {
		int len = a.size();
		if((len&1)==0)
			return LISutil(a, 0, len/2);
		else return LISutil(a, 0, len/2+1);
	}

}
