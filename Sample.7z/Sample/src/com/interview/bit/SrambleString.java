/**
 * 
 */
package com.interview.bit;

import java.util.Arrays;

/**
 * @author RushabhkumarKhandare
 *
 */
public class SrambleString {
	public static int isScramble(final String A, final String B) {
		if (A.length() != B.length())
			return 0;
		char[] a = A.toCharArray();
		char[] b = B.toCharArray();
		Arrays.sort(a);
		Arrays.sort(b);
		if (String.valueOf(a).equals(String.valueOf(b)))
			return 1;
		else
			return 0;

	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		System.out.println(isScramble("abbbcbaaccacaacc","acaaaccabcabcbcb"));

	}

}
