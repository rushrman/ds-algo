/**
 * 
 */
package com.interview.bit;

/**
 * @author RushabhkumarKhandare
 *
 */
public class interleavingString {
	// approach with bug
	public static int isInterleave(String A, String B, String C) {
		int m = A.length();
		int n = B.length();
		if(m+n!=C.length())
			return 0;
		boolean[][] IL = new boolean[m + 1][n + 1];
		for (int i = 0; i <= m; i++) {
			for (int j = 0; j <= n; j++) {
				if (i == 0 && j == 0)
					IL[i][j] = true;
				else if (i == 0 && B.charAt(j - 1) == C.charAt(j - 1))
					IL[i][j] = IL[i][j - 1];
				else if (j == 0 && A.charAt(i - 1) == C.charAt(i - 1))
					IL[i][j] = IL[i - 1][j];
				else if (i > 0 && j > 0 && A.charAt(i - 1) == C.charAt(i + j - 1)
						&& B.charAt(j - 1) != C.charAt(i + j - 1))
					IL[i][j] = IL[i - 1][j];
				else if (i > 0 && j > 0 && A.charAt(i - 1) != C.charAt(i + j - 1)
						&& B.charAt(j - 1) == C.charAt(i + j - 1))
					IL[i][j] = IL[i][j - 1];
				else if(i > 0 && j > 0 &&  A.charAt(i - 1) == C.charAt(i + j - 1)&&B.charAt(j - 1) == C.charAt(i + j - 1))
					IL[i][j] = IL[i - 1][j] || IL[i][j - 1];
			}
		}
		if (IL[m][n])
			return 1;
		else
			return 0;
	}

	public static int isInterleaved(String a, String b, String c) {
		if(a.length()+b.length()!=c.length())
			return 0;
		boolean[][] res = new boolean[a.length()][b.length()];
		int k = 0;
		for (int i = 0; i < a.length(); i++) {
			for (int j = 0; j < b.length(); j++) {
				k = i + j - 1;
				if (i == 0 && j == 0)
					res[0][0] = true;

				else if (i > 0 && a.charAt(i - 1) == c.charAt(k) || j > 0 && b.charAt(j - 1) == c.charAt(k))
					res[i][j] = res[i - 1][j] || res[i][j - 1];

			}
		}
		if(res[a.length() - 1][b.length() - 1])
			return 1;
		else return 0;
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(isInterleaved("USfMSU", "5YgZ9N5mR6ppfggzbzh7HTox85MwFtaIQDHfzJW8vc2G", "5YgUSZf9NM5SmR6Uppfggzbzh7HTox84MwFtaIQDHfzJW8vc2G"));
	}

}
