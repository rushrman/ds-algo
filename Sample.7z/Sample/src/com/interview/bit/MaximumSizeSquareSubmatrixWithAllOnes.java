/**
 * 
 */
package com.interview.bit;

/**
 * @author RushabhkumarKhandare
 *
 */
public class MaximumSizeSquareSubmatrixWithAllOnes {
	public static int maximumSizeSquareSubmatrixWithAllOnes(int[][] matrix) {
		int r = matrix.length;
		int c = matrix[0].length;
		int maxsize = 0;
		int[][] table = new int[r][c];
		for (int i = 0; i < r; i++) {
			for (int j = 0; j < c; j++) {
				if (i == 0 || j == 0)
					table[i][j] = matrix[i][j];
				else if (matrix[i][j] == 0)
					table[i][j] = 0;
				else {
					table[i][j] = min(table[i - 1][j - 1], table[i][j - 1], table[i - 1][j]) + 1;
				}
				if (maxsize < table[i][j])
					maxsize = table[i][j];
			}
		}
		return maxsize;
	}

	private static int min(int i, int j, int k) {
		// TODO Auto-generated method stub
		return 0;
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
