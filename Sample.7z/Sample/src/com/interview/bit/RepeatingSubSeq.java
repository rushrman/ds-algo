package com.interview.bit;

public class RepeatingSubSeq {
	public static int anytwo(String A) {
		 char[] str = A.toCharArray();
	        int n = str.length;
	        int[] freq = new int[256];
	        int maxfreq=0;
	        int count=0;
	        if(A.length()==2&&A.charAt(0)!=A.charAt(1))
	            return 0;
	        for (int i = 0; i < n; i++) {
	            freq[str[i]]++;
	            if(maxfreq<freq[str[i]]){
	             maxfreq=freq[str[i]];
	            }
	            if (freq[str[i]] == 2)
	            	count++;
	            if (freq[str[i]] > 2)
	                return 1;
	        }
	        if(maxfreq<2&&count<2)
	            return 0;
	        int k = 0;
	        for (int i = 0; i < n; i++) {
	            if (freq[str[i]] > 1)
	                str[k++] = str[i];
	        }
	        if (isPalindrom(str)) {
	            return 0;
	        }
	        return 1;
	    }
	

	private static boolean isPalindrom(char[] str) {
		int l = 0, h = str.length - 1;
		while (l < h) {
			if (str[l++] != str[h--])
				return false;
		}
		return true;
	}
	public static void main(String[] args){
		System.out.println(anytwo("wrBq"));
	}
}
