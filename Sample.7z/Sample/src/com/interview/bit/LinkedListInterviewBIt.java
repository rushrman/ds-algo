package com.interview.bit;

public class LinkedListInterviewBIt {
	public static int lPalin(ListNode A) {
		if (A == null || A.next == null)
			return 1;
		ListNode a = finMiddle(A);
		a = reverseList(a);
		ListNode oA = A;
		while (oA != null && a != null) {
			if (oA.val != a.val) {
				return 0;
			}
			oA = oA.next;
			a = a.next;
		}
		return 1;
	}

	private static ListNode reverseList(ListNode a) {
		ListNode curr = a;
		ListNode prev = null;
		ListNode next = null;
		if (a == null || a.next == null)
			return a;
		while (curr != null) {
			next = curr.next;
			curr.next = prev;
			prev = curr;
			curr = next;
		}
		return prev;
	}

	private static ListNode finMiddle(ListNode a) {
		ListNode slow = a;
		ListNode fast = a;
		while (fast != null && fast.next != null) {
			slow = slow.next;
			fast = fast.next.next;
		}
		return slow;
	}

	public static ListNode deleteDuplicates(ListNode A) {
		ListNode a = A;
		while (a.next != null) {
			while (a.val == a.next.val) {
				a.next = a.next.next;
			}
			a = a.next;
		}
		return A;
	}

	public static ListNode deleteDuplicatesII(ListNode A) {
		ListNode dummy = new ListNode(0);
		dummy.next = A;
		ListNode prev = dummy;
		ListNode current = A;
		while (current != null) {
			while (current.next != null && prev.next.val == current.next.val) {
				current = current.next;
			}
			if (prev.next == current) {
				prev = prev.next;
			} else {
				prev.next = current.next;
			}
			current = current.next;
		}
		A = dummy.next;
		return A;
	}

	public ListNode mergeTwoLists(ListNode A, ListNode B) {
		ListNode dummy = new ListNode(0);
		ListNode tail = dummy.next;
		while (true) {
			if (A == null) {
				tail.next = B;
				break;
			}
			if (B == null) {
				tail.next = A;
				break;
			}
			if (A.val <= B.val) {
				tail.next = A;
				A = A.next;
			} else {
				tail.next = B;
				B = B.next;
			}
			tail = tail.next;
		}
		return dummy.next;
	}

	public static ListNode removeNthFromEnd(ListNode A, int B) {
		ListNode curr = A;
		ListNode head = A;
		int a = B;
		while (curr != null && a > 0) {
			curr = curr.next;
			a--;
		}
		ListNode temp = A;
		if (curr == null) {
			A = null;
		}
		while (curr != null) {
			temp = temp.next;
			curr = curr.next;
		}
		while (A != null && A.next != temp) {
			A = A.next;
		}
		if (A.next != null) {
			A.next = A.next.next;
		}
		return head;
	}

	public static ListNode rotateRight(ListNode A, int B) {
		ListNode headOriginal = A;
		ListNode head = A;
		ListNode temp = A;
		if (A == null)
			return null;

		ListNode tempCal = A;
		int count = 0;
		while (tempCal != null) {
			tempCal = tempCal.next;
			count++;
		}
		if (B > count) {
			B = B % count;
			while (B > count) {
				B = count % B;
			}
		}

		while (count > 0) {
			head = head.next;
			count--;
		}
		if (head == null) {
			A = reverseList(A);
			return A;
		}
		while (head.next != null) {
			temp = temp.next;
			head = head.next;
		}
		ListNode roatateHead = temp.next;
		ListNode rotate = temp.next;
		temp.next = null;
		while (rotate.next != null) {
			rotate = rotate.next;
		}
		rotate.next = headOriginal;
		return roatateHead;
	}

	public static ListNode reverseBetween(ListNode A, int B, int C) {
		ListNode curr = A;
		ListNode rev_start = null;
		ListNode rev_prev = null;
		ListNode rev_end = null;
		ListNode rev_end_next = null;
		ListNode prev = null;
		ListNode next = null;
		int count = 1;
		while (curr != null) {
			if (count == B) {
				rev_start = curr;
				rev_prev = prev;
			}
			if (count == C) {
				rev_end = curr;
				rev_end_next = curr.next;
			}
			prev = curr;
			curr = curr.next;
			count++;
		}
		if (count == 1)
			return A;
		if (rev_prev != null)
			rev_prev.next = null;
		rev_end.next = null;
		curr = rev_start;
		prev = null;
		while (curr != null) {
			next = curr.next;
			curr.next = prev;
			prev = curr;
			curr = next;
		}
		if (rev_prev != null) {
			rev_prev.next = rev_end;
		} else {
			A = rev_end;
		}
		rev_start.next = rev_end_next;
		return A;
	}

	public static ListNode reorderList(ListNode A) {
		if (A.next == null || A == null)
			return A;
		ListNode slow = A;
		ListNode fast = A;
		while (fast != null && fast.next != null) {
			slow = slow.next;
			fast = fast.next.next;
		}
		ListNode A2 = reverseList(slow.next);
		slow.next = null;
		ListNode temp = new ListNode(0);
		ListNode curr = temp;
		while (A != null || A2 != null) {
			if (A != null) {
				curr.next = A;
				curr = curr.next;
				A = A.next;
			}
			if (A2 != null) {
				curr.next = A2;
				curr = curr.next;
				A2 = A2.next;
			}
		}
		temp = temp.next;
		return temp;
	}

	public static ListNode reverseKSubList(ListNode A, int B) {
		ListNode curr = A;
		ListNode prev = null;
		ListNode next = null;
		int count = 0;
		while (count < B && curr != null) {
			next = curr.next;
			curr.next = prev;
			prev = curr;
			curr = next;
			count++;
		}
		if (next != null)
			A.next = reverseKSubList(next, B);
		return prev;
	}

	public static ListNode swapPairs(ListNode A) {
		if (A == null || A.next == null)
			return A;
		ListNode curr = A;
		int temp;
		while (curr != null && curr.next != null) {
			temp = curr.val;
			curr.val = curr.next.val;
			curr.next.val = temp;
			curr = curr.next.next;
		}
		return A;
	}

	public static ListNode addTwoNumbers(ListNode A, ListNode B) {
		// ListNode node = new ListNode(0);
		ListNode newHead = null;
		ListNode prev = null;
		ListNode newNode = null;
		int carry = 0;
		int sum = 0;
		while (A != null || B != null) {
			sum = (A != null ? A.val : 0) + (B != null ? B.val : 0) + carry;
			carry = (sum >= 10) ? 1 : 0;
			sum = sum % 10;
			newNode = new ListNode(sum);
			if (newHead == null) {
				newHead = newNode;
			} else {
				prev.next = newNode;
			}
			prev = newNode;

			if (A != null)
				A = A.next;
			if (B != null)
				B = B.next;
		}
		if (carry > 0) {
			newNode.next = new ListNode(carry);
		}
		return newHead;
	}

	public static ListNode detectCycle(ListNode a) {
		ListNode slow = a;
		ListNode fast = a;
		while (fast.next != null && fast != null) {
			slow = slow.next;
			fast = fast.next.next;
			if (slow == fast) {
				break;
			}
		}
		if (fast == null || fast.next == null) {
			return null;
		}
		ListNode start = a;
		while (slow != start) {
			slow = slow.next;
			start = start.next;
		}
		ListNode temp = new ListNode(slow.next.val);
		return temp;
	}

	public static ListNode partition(ListNode A, int B) {
		ListNode headLessThan = null;
		ListNode headGreaterThan = null;
		ListNode tempL = new ListNode(0);
		ListNode tempG = new ListNode(0);
		while (A != null) {
			ListNode t = new ListNode(A.val);
			if (A.val < B) {
				if (headLessThan == null) {
					headLessThan = t;
					tempL.next = headLessThan;
				} else {
					tempL.next = t;
				}
				tempL = tempL.next;
			} else {
				if (headGreaterThan == null) {
					headGreaterThan = t;
					tempG.next = headGreaterThan;
				} else {
					tempG.next = t;
				}
				tempG = tempG.next;
			}
			A = A.next;
		}
		tempL.next = headGreaterThan;
		if(headLessThan==null)
			return headLessThan;
		return headLessThan;
	}

	public static void main(String args[]) {
		ListNode a = new ListNode(1);
		a.next = new ListNode(4);
		a.next.next = new ListNode(3);
		a.next.next.next = new ListNode(2);
		a.next.next.next.next = new ListNode(5);
		a.next.next.next.next.next = new ListNode(2);
		//a.next.next.next.next = a.next.next;
		/*
		 * a.next.next = new ListNode(7); a.next.next = new ListNode(7);
		 */
		// deleteDuplicatesII(a);
		ListNode b = new ListNode(1);
		// b.next = new ListNode(6);
		// b.next.next = new ListNode(4);
		// removeNthFromEnd(a, 2);
		// rotateRight(b, 1);
		// reverseBetween(a, 1, 2);
		// reorderList(a);
		// swapPairs(a);
		// addTwoNumbers(b, a);
		//detectCycle(a);
		partition(a,3);
		b = a.next;

		// a.next.next.next = new ListNode(3);
		// a.next.next.next.next = new ListNode(6);
		// System.out.println(lPalin(a));
	}

}

class ListNode {
	public int val;
	public ListNode next;

	ListNode(int x) {
		val = x;
		next = null;
	}
}
