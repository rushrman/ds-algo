package com.interview.bit;

public class MinJumps {
	public static int minjumps(int[] a) {
		if (a[0] == 0)
			return -1;
		int steps = a[0];

		int ladder = a[0];
		int mijumps = 1;
		for (int i = 1; i < a.length; i++) {
			if (i == a.length - 1)
				return mijumps;
			if (ladder < a[i] + i)
				ladder = a[i] + i;
			steps--;
			if (steps == 0) {
				mijumps++;
				if (i >= ladder)
					return -1;
				steps = ladder - i;
			}
		}
		return -1;
	}

	public static void main(String[] args) {
		int arr[] = { 1, 3, 6, 1, 0, 9 };
		System.out.println(minjumps(arr));

	}

}
