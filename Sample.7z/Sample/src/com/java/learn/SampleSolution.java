package com.java.learn;

public class SampleSolution extends Test{
	
	private void m1(){
		System.out.println("Derived");
	}
	
	public static void main(String args[]){
//		Test t = (Test)new SampleSolution(); //upcasting
//		SampleSolution t1 = (SampleSolution) t; //downcasting
		Test t = new SampleSolution();
		//t.m1();
	}
}

class Test{
	 private void m1(){
		System.out.println("Base");
	}
}