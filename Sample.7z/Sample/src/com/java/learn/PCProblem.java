package com.java.learn;

public class PCProblem {
	final static PC pc = new PC();

	public static void main(String[] args) throws InterruptedException {
		Thread t1 = new Thread(new Runnable() {
			@Override
			public void run() {
				try {
					pc.producer();
				} catch (Exception e) {

				}

			}
		});
		Thread t2 = new Thread(new Runnable() {
			@Override
			public void run() {
				try {
					pc.consumer();
				} catch (Exception e) {

				}

			}
		});
		t1.start();
		t2.start();

		t1.join();
		t2.join();
	}

}

class PC {
	static int count = 0;

	public void producer() throws InterruptedException {
		Thread.sleep(100);
		synchronized (PC.class) {
			wait();
			System.out.println("This is Producer!!" + count);
		}
	}

	public void consumer() throws InterruptedException {
		// Thread.sleep(100);
		synchronized (this) {
			wait();
			count++;
			System.out.println("This is Consumer!!" + count);
		}
	}
}