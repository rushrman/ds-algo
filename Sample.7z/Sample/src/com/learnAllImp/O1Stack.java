/**
 * 
 */
package com.learnAllImp;

/**
 * @author RushabhkumarKhandare
 *
 */
public class O1Stack {
	static MyStack mystack = new MyStack();
	static int minEle;

	public static int pop() {
		int result;
		if (mystack.isEmpty()) {
			return -1;
		} else {
			int x = mystack.pop();
			if (x < minEle) {
				result = minEle;
				minEle = 2 * minEle - x;
			} else {
				result = x;
			}
			return result;
		}
	}

	public static void push(int x) {
		if (mystack.full()) {
			System.out.println("Stack full");
		} else {
			if (x < minEle) {
				mystack.push(2 * x - minEle);
				minEle = x;
			}else mystack.push(x);
		}
	}
	public static int getMin(){
		if(mystack.isEmpty())
			return -1;
		else return minEle;
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}

class MyStack {
	int top = -1;
	int[] arr = new int[100];

	public void push(int x) {
		if (top == 99)
			System.out.println("Statck is full!!");
		else {
			arr[top++] = x;
		}
	}

	public int pop() {
		int result = arr[top];
		top--;
		return result;
	}

	public boolean isEmpty() {
		if (top == -1)
			return true;
		else
			return false;
	}

	public int peek() {
		if (top != -1)
			return arr[top];
		else
			return top;
	}

	public boolean full() {
		if (top != 99)
			return false;
		else
			return true;
	}
}
