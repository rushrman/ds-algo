/**
 * 
 */
package com.learnAllImp;

import java.util.Deque;
import java.util.LinkedList;

/**
 * @author RushabhkumarKhandare
 *
 */
public class SlidingWindow {
	public static void printMaxFromkSubarray(int[] a, int k) {
		Deque<Integer> Qi = new LinkedList<>();
		int i = 0;
		for (; i < k; i++) {
			while (!Qi.isEmpty() && a[i] >= Qi.peekLast())
				Qi.removeLast();
			Qi.addLast(a[i]);
		}
		for (; i < a.length; i++) {
			System.out.println(Qi.peek());
			while (!Qi.isEmpty() && Qi.peek() <= i - k)
				Qi.removeFirst();
			while (!Qi.isEmpty() && a[i] >= Qi.peekLast())
				Qi.removeLast();
			Qi.addLast(a[i]);
		}
		System.out.println(Qi.peek());
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
