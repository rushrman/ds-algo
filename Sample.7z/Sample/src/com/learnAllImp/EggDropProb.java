/**
 * 
 */
package com.learnAllImp;

/**
 * @author RushabhkumarKhandare
 *
 */
public class EggDropProb {
	public static int eggdrop(int n, int k) {
		// n - eggs k - floors
		if (n == 1)
			return k;
		if (k == 1 || k == 0)
			return k;
		int res = 0, min = Integer.MAX_VALUE;
		for (int x = 1; x <= k; x++) {
			res = Math.max(eggdrop(n - 1, x - 1), eggdrop(n, k - x));
			if (res < min)
				min = res;
		}
		return min + 1;
	}

	public static int eggdropDP(int n, int k) {
		int[][] eggdrop = new int[n + 1][k + 1];
		int res = 0;
		for (int i = 1; i <= n; i++) {
			eggdrop[i][0] = 0;
			eggdrop[i][1] = 1;
		}
		for (int i = 1; i <= k; i++) {
			eggdrop[1][i] = i;
		}
		for (int i = 2; i <= n; i++) {
			for (int j = 2; j <= k; j++) {
				eggdrop[i][j] = Integer.MAX_VALUE;
				for (int x = 1; x <= k; x++) {
					res = Math.max(eggdrop[i - 1][x - 1], eggdrop[i][j - x]);
					if (res < eggdrop[i][j])
						eggdrop[i][j] = res;
				}
			}
		}
		return eggdrop[n][k];
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
