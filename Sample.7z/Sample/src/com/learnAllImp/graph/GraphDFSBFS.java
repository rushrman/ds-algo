/**
 * 
 */
package com.learnAllImp.graph;

import java.util.Iterator;
import java.util.LinkedList;

/**
 * @author RushabhkumarKhandare
 *
 */
public class GraphDFSBFS {
	int V;
	LinkedList<Integer>[] adj;

	public GraphDFSBFS(int v) {
		this.V = v;
		adj = new LinkedList[v];
		for (int i = 0; i < v; i++)
			adj[i] = new LinkedList<Integer>();
	}

	void addEdge(int w, int v) {
		adj[w].add(v);
	}

	void dfs(int v) {
		boolean[] visited = new boolean[v];
		for (int i = 0; i < v; i++)
			if (!visited[i])
				dfsutil(i, visited);
	}

	private void dfsutil(int v, boolean[] visited) {
		visited[v] = true;
		System.out.print(v + " ");
		Iterator<Integer> itr = adj[v].listIterator();
		while (itr.hasNext()) {
			int n = itr.next();
			if (!visited[n])
				dfsutil(n, visited);
		}

	}

	void bfs(int v) {
		boolean[] visited = new boolean[v];
		visited[v] = true;
		LinkedList<Integer> queue = new LinkedList<>();
		queue.add(v);
		while (!queue.isEmpty()) {
			int n = queue.poll();
			System.out.println(n + " ");
			Iterator<Integer> itr = adj[n].iterator();
			while (itr.hasNext()) {
				int k = itr.next();
				if (!visited[k]) {
					visited[k] = true;
					queue.add(k);
				}
			}
		}
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
