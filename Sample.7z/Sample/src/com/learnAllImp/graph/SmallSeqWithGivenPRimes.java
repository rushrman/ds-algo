/**
 * 
 */
package com.learnAllImp.graph;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

/**
 * @author RushabhkumarKhandare
 *
 */
public class SmallSeqWithGivenPRimes {
	public static ArrayList<Integer> solve(int A, int B, int C, int D) {
        ArrayList<Integer> numbers = new ArrayList<>();
        if(D==0)
        	return numbers;
        Set<Integer> st = new HashSet<>();
        st.add(A);st.add(B);st.add(C);
        Iterator<Integer> itr = st.iterator();
        while(itr.hasNext()){
        	int curr = itr.next();
        	itr.remove();
        	numbers.add(curr);
        	if(numbers.size()==D)
        		break;
        	int p1 = curr*A;
        	int p2 = curr*B;
        	int p3 = curr*C;
        	st.add(p1);st.add(p2);st.add(p3);
        }
        return numbers;
     }
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		System.out.println(solve(2, 5, 11, 3));
Set<String> fruits = new HashSet<>();
		
		fruits.add("Apple");
		fruits.add("Banana");
		fruits.add("Orange");
		fruits.add("Mango");
		
		Iterator<String> iterator = fruits.iterator();
		
		while(iterator.hasNext()){
			String fruit = iterator.next();
			System.out.println("Processing "+fruit);
			
			//correct way of structural modification of Set
			if("Orange".equals(fruit)) iterator.remove();
		}
		System.out.println("fruits set after iteration = "+fruits);
	}

}
