/**
 * 
 */
package com.learnAllImp.graph;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

/**
 * @author RushabhkumarKhandare
 *
 */
public class MinNoOfSwaps {
	public int minNoOfSwaps(int[] a) {
		int ans = 0;
		ArrayList<Pair> arrpos = new ArrayList<>();
		for (int i = 0; i < a.length; i++) {
			arrpos.add(new Pair(a[i], i));
		}
		Collections.sort(arrpos, new Comparator<Pair>() {
			public int compare(Pair o1, Pair o2) {
				if (o1.a > o2.a)
					return 1;
				else if (o1.a == o2.a)
					return 0;
				else
					return -1;

			};
		});

		boolean[] visited = new boolean[a.length];

		for (int i = 0; i < a.length; i++) {
			if (visited[i] || arrpos.get(i).i == i)
				continue;

			int cycle = 0;
			int j = i;
			while (!visited[j]) {
				visited[j] = true;
				cycle++;
				j = arrpos.get(j).i;

			}
			if (cycle > ans)
				ans += cycle - 1;
		}
		return ans;
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int []a = {1, 5, 4, 3, 2}; 
		MinNoOfSwaps g = new MinNoOfSwaps(); 
        System.out.println(g.minNoOfSwaps(a)); 

	}

}

class Pair {
	int a, i;

	Pair(int a, int i) {
		this.a = a;
		this.i = i;
	}
}