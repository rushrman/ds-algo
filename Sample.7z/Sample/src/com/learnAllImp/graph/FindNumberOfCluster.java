/**
 * 
 */
package com.learnAllImp.graph;

/**
 * @author RushabhkumarKhandare
 *
 */
public class FindNumberOfCluster {
	static int[] offsets = { -1, 0, 1 };

	public int findClusters(int[][] matrix) {
		int count = 0;
		int r = matrix.length;
		int c = matrix[0].length;
		boolean[][] visited = new boolean[r][c];
		for (int i = 0; i < r; i++) {
			for (int j = 0; j < c; j++) {
				if (matrix[i][j] == 1 && !visited[i][j]) {
					count++;
					doDfs(matrix, i, j, visited);
				}
			}
		}
		return count;
	}

	private void doDfs(int[][] matrix, int i, int j, boolean[][] visited) {
		if (visited[i][j])
			return;
		visited[i][j] = true;
		int xofset, yofset;
		for (int m = 0; m < offsets.length; m++) {
			xofset = offsets[m];
			for (int n = 0; n < offsets.length; n++) {
				yofset = offsets[n];
				if (xofset == 0 && yofset == 0) {
					continue;
				}
				if (neighbhorExits(matrix, i + xofset, j + yofset)) {
					doDfs(matrix, i + xofset, j + yofset, visited);
				}

			}
		}
	}

	private boolean neighbhorExits(int[][] matrix, int i, int j) {
		if (i >= 0 && i < matrix.length && j >= 0 && j < matrix[0].length) {
			if (matrix[i][j] == 1)
				return true;
		}
		return false;
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
