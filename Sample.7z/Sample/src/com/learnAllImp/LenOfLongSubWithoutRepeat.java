/**
 * 
 */
package com.learnAllImp;

/**
 * @author RushabhkumarKhandare
 *
 */
public class LenOfLongSubWithoutRepeat {
	public static void lenOfLongSubWithoutRepeat(String str) {
		int len = str.length();
		int curr_len = 0;
		int max_len = 0;
		int[] visited = new int[256];
		int prevIndex = -1;
		for (int i = 0; i < 256; i++)
			visited[i] = -1;
		visited[str.charAt(0)] = 0;
		for (int i = 1; i < len; i++) {
			prevIndex = visited[str.charAt(i)];
			if (prevIndex == -1 || i - curr_len > prevIndex)
				curr_len++;
			else {
				if (max_len < curr_len)
					max_len = curr_len;
				curr_len=i-prevIndex;
				visited[str.charAt(i)]=i;
			}
		}
		if (max_len < curr_len)
			max_len = curr_len;
		System.out.println(max_len);
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
