/**
 * 
 */
package com.visaa.test;

/**
 * @author RushabhkumarKhandare
 *
 */
public class BlueOptima {
	static int[] BS(int[] A) {
		int[] b = new int[A.length];
		for (int i = 0; i < b.length; i++)
			b[i] = 1;
		for (int i = 1; i < A.length; i++) {
			for (int j = 0; j < i; j++) {
				if (A[i] >= A[j] && b[i] < b[j] + 1) {
					b[i] = b[j] + 1;
				}
			}
		}
		return b;
	}

	public static void main(String[] args) {
		final int [] a= {1};
		int [] b= {1};
		System.out.println(BS(a));

	}

}
