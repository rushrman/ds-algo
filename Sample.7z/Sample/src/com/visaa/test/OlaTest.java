package com.visaa.test;

public class OlaTest {

	public static String longestRepeatingSubStringNonOverlapping(String str) {
		String res = "";
		int index = 0, res_length = 0;
		int[][] lcs = new int[str.length() + 1][str.length() + 1];
		for (int i = 1; i < str.length(); i++) {
			for (int j = i + 1; j < str.length(); j++) {
				if (str.charAt(i-1) == str.charAt(j-1)&& lcs[i-1][j-1] < j - i) {
					lcs[i][j] = lcs[i - 1][j - 1] + 1;
					if (res_length < lcs[i][j]) {
						res_length = lcs[i][j];
						index = Math.max(i, index);
					}
				} else
					lcs[i][j] = 0;
			}
		}
		for (int i = index - res_length+1; i <= index; i++) {
			res += str.charAt(i-1);
		}
		return res;
	}
	
	public static void main(String[] args) {
		String str = "ababab";
		System.out.println("The input string is " + str);
		String len = longestRepeatingSubStringNonOverlapping(str);
		System.out.println("The length of " + "the longest non repeating character is " + len);

	}
}
