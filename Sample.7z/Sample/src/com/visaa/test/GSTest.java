/**
 * 
 */
package com.visaa.test;

/**
 * @author RushabhkumarKhandare
 *
 */
public class GSTest {
	public static int findDamagedToy(int N, int T, int D) {
		int i = D;
		int[] arr = new int[N + 1];
		while (T > 0 && i >= 0) {
			if (i > N) {
				i = i % N;
			}
			arr[i] += 1;
			i++;
			T--;
		}
		i = i % N;
		return i - 1;
	}

	static int findPossibleSmallestNumberMatchingPattern(String pattern) 
    { 
        int n = pattern.length(); 
  
        if (n >= 9) 
            return -1; 
  
        char result[] = new char[n + 1]; 
  
        int count = 1; 
  
        for (int i = 0; i <= n; i++) 
        { 
            if (i == n || pattern.charAt(i) == 'N') 
            { 
                for (int j = i - 1; j >= -1; j--) 
                { 
                    result[j + 1] = (char) ((int) '0' + count++); 
                    if (j >= 0 && pattern.charAt(j) == 'N') 
                        break; 
                } 
            } 
        } 
        return Integer.valueOf(String.valueOf(result)); 
    } 

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// System.out.println(findDamagedToy(10,2,0));
		System.out.println(findPossibleSmallestNumberMatchingPattern("MNM"));
	}

}
