/**
 * 
 */
package com.visaa.test;

import java.util.HashSet;
import java.util.Set;

/**
 * @author RushabhkumarKhandare
 *
 */
public class LendingKart {
	static int MAX_NO_CHARS = 256;

	public static int longestUniqueSubStr(String str) {
		int curr_len = 1;
		int max_len = 1;
		int prev_index;
		int i;
		int[] visited = new int[MAX_NO_CHARS];
		for (i = 0; i < MAX_NO_CHARS; i++) {
			visited[i] = -1;
		}
		/* Storing indexes */
		visited[str.charAt(0)] = 0;
		for (int j = 1; j < str.length(); j++) {
			prev_index = visited[str.charAt(j)];
			if (prev_index == -1 || j - curr_len > prev_index)
				curr_len++;
			else {
				if (curr_len > max_len)
					max_len = curr_len;

				curr_len = j - prev_index;
			}
			visited[str.charAt(j)] = j;
		}
		if (curr_len > max_len)
			max_len = curr_len;
		return max_len;
	}

	public static int longNonRepeatSubString(String str) {
		int i = 0, j = 0, maxcount = 0;
		Set<Character> st = new HashSet<>();
		while (i < str.length() && j < str.length()) {
			if (!st.contains(str.charAt(j))) {
				st.add(str.charAt(j));
				j++;
				maxcount = Math.max(maxcount, j - i);
			} else {
				st.remove(str.charAt(i));
				i++;
			}
		}
		return maxcount;
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		String str = "ABEFGABEFJTRMNVXZ";
		System.out.println("The input string is " + str);
		int len = longestUniqueSubStr(str);
		System.out.println("The length of " + "the longest unique/non repeating character is " + len);

	}

}
