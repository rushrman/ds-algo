package com.visaa.test;

public class WMInter {
	/*
	 * Find substring with k unique characters
	 */
	public static int findKuniqueCharsSubstring(String input) {
		int maxLen = 0;
		for(int i=0;i<input.length();i++){
			
		}
		return maxLen;
	}

	class Res {
		int startIndex;
		int ednIndex;
	}

	public static void main(String[] args) {
		findKuniqueCharsSubstring("abababbbbbaabbacddddddddddddddddddddddddddddddddddddddd");

	}

}
