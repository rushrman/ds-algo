package com.visaa.test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class KredX {
	static int solveRec(int[] p, int n, int prev) {
		int result = 0;
		if (n == p.length)
			return 0;
		if (prev != -1) {
			if (p[n] % p[prev] == 0) {
				result += p[n];
			}
		} else {
			result += p[n];
		}
		return Math.max(result + solveRec(p, n + 1, n), solveRec(p, n + 1, prev));
	}

	static int solve(int[] p) {
		int[] res = new int[p.length];
		int result = p[0];
		int prevIndex = 0;
		for (int i = 1; i < p.length; i++) {
			if (p[prevIndex] == 1) {
				result += p[i];
				prevIndex = i;
			} else if (p[i] % p[prevIndex] == 0) {
				result += p[i];
				prevIndex = i;
			}

		}
		return result;
	}

	static String Solution(String A, String C, String B) {
		HashMap<Character, List<Character>> map = new HashMap<>();
		for (int i = 0; i < A.length(); i++) {
			if (map.containsKey(A.charAt(i))) {
				map.get(A.charAt(i)).add(B.charAt(i));
			} else {
				List<Character> list = new ArrayList<>();
				list.add(B.charAt(i));
				map.put(A.charAt(i), list);
				if(map.containsKey(B.charAt(i))){
					map.get(B.charAt(i)).add(A.charAt(i));
				}else{
					list = new ArrayList<>();
					list.add(A.charAt(i));
					map.put(B.charAt(i), list);
				}
				
			}
		}

		String res = "";
		for (int i = 0; i < C.length(); i++) {
			if (map.get(C.charAt(i)) != null) {
				res = res + map.get(C.charAt(i)).get(0);
			} else {
				res += C.charAt(i);
			}
		}
		return res;

	}

	public static void main(String args[]) {
		int[] a = { 1, 2, 3, 4, 9, 8 };
		System.out.println(solveRec(a, 0, -1));
	}

}
