/**
 * 
 */
package com.visaa.test;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;

/**
 * @author RushabhkumarKhandare
 *
 */

public class AWSTest {

	// METHOD SIGNATURE BEGINS, THIS METHOD IS REQUIRED
	static ArrayList<Integer> IDsOfSongs(int rideDuration, ArrayList<Integer> songDurations) {
		ArrayList<Integer> res = new ArrayList<>();
		HashSet<Integer> s = new HashSet<Integer>();
		Collections.sort(songDurations);
		for (int i = 0; i < songDurations.size(); ++i) {
			int temp = rideDuration - 30 - songDurations.get(i);

			// checking for condition
			if (temp >= 0 && s.contains(songDurations.indexOf(temp))) {
				if(res.size()==2){
					int m =res.get(0);
					int n =res.get(1);
					if(songDurations.get(m)+songDurations.get(n)>songDurations.get(i)+temp){
						res.add(0, m);
						res.add(1, n);
					}
				}else if(res.size()==0){
					res.add(0,songDurations.indexOf(temp));
					res.add(1,i);
				}
			}
			s.add(i);
		}
		/*int r=0;
		ArrayList<Integer> newr = new ArrayList<Integer>();
		if(res.size()>2){
			for(int i=0;i<res.size()-1;i++){
				if(r<songDurations.get(res.get(i))+songDurations.get((res.get(i+1)))){
					r=songDurations.get(res.get(i))+songDurations.get((res.get(i+1)));
					newr.add(res.get(i));
					newr.add(res.get(i+1));
				}
			}
		}*/
		return res;
		/*
		 * for (int i = 0; i < songDurations.size() - 1; i++) { if
		 * (songDurations.get(i) + songDurations.get(i + 1) + 30 ==
		 * rideDuration) { if (result < songDurations.get(i) +
		 * songDurations.get(i + 1)) { result = songDurations.get(i) +
		 * songDurations.get(i + 1); j = i; k = i + 1; } } }
		 * res.add(songDurations.get(j)); res.add(songDurations.get(k));
		 */
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		ArrayList<Integer> songDurations = new ArrayList<>();
		songDurations.add(1);
		songDurations.add(10);
		songDurations.add(25);
		songDurations.add(35);
		songDurations.add(25);
		songDurations.add(35);
		songDurations.add(60);
		System.out.println(IDsOfSongs(90, songDurations));
	}

}
