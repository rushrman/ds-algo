package com.visaa.test;

//Java Program to Implement a Phone 
//Directory Using Trie Data Structure 
import java.util.*;

class TrieNode {
	// Each Trie Node contains a Map 'child'
	// where each alphabet points to a Trie
	// Node.
	HashMap<Character, TrieNode> child;

	// 'isLast' is true if the node represents
	// end of a contact
	boolean isLast;

	// Default Constructor
	public TrieNode() {
		child = new HashMap<Character, TrieNode>();

		// Initialize all the Trie nodes with NULL
		for (char i = 'a'; i <= 'z'; i++)
			child.put(i, null);

		isLast = false;
	}
}

class Trie {
	static TrieNode root = null;

	// Insert a Contact into the Trie
	public static void insert(String s) {
		int len = s.length();

		// 'itr' is used to iterate the Trie Nodes
		TrieNode itr = root;
		for (int i = 0; i < len; i++) {
			// Check if the s[i] is already present in
			// Trie
			TrieNode nextNode = itr.child.get(s.charAt(i));
			if (nextNode == null) {
				// If not found then create a new TrieNode
				nextNode = new TrieNode();

				// Insert into the HashMap
				itr.child.put(s.charAt(i), nextNode);
			}

			// Move the iterator('itr') ,to point to next
			// Trie Node
			itr = nextNode;

			// If its the last character of the string 's'
			// then mark 'isLast' as true
			if (i == len - 1)
				itr.isLast = true;
		}
	}

	// This function simply displays all dictionary words
	// going through current node. String 'prefix'
	// represents string corresponding to the path from
	// root to curNode.
	static int count = 0;

	public static int displayContactsUtil(TrieNode curNode, String prefix) {

		// Check if the string 'prefix' ends at this Node
		// If yes then display the string found so far
		if (curNode.isLast)
			count++;

		// Find all the adjacent Nodes to the current
		// Node and then call the function recursively
		// This is similar to performing DFS on a graph
		for (char i = 'a'; i <= 'z'; i++) {
			TrieNode nextNode = curNode.child.get(i);
			if (nextNode != null) {
				return displayContactsUtil(nextNode, prefix + i);
			}
		}
		return count;
	}

	// Display suggestions after every character enter by
	// the user for a given string 'str'
	static List<Integer> displayContacts(List<String> names, List<String> query) {
		root = new TrieNode();
		for (String s : names) {
			insert(s);
		}
		TrieNode prevNode = root;

		// 'flag' denotes whether the string entered
		// so far is present in the Contact List

		String prefix = "";
		List<Integer> list = new ArrayList<>();
		for (String str : query) {
			TrieNode curNode = prevNode.child.get(str.charAt(0));
			if (curNode != null) {
				count = 0;
				list.add(displayContactsUtil(curNode, prefix));
			} else {
				list.add(0);
			}

		}
		return list;
	}
}

// Testing class
public class Test {
	public static void main(String args[]) {
		Trie trie = new Trie();
		List<String> names=new ArrayList<>();
		names.add("steve");
		names.add("stevens");names.add("danny");names.add("alex");names.add("alexander");names.add("steves");
		List<String> query=new ArrayList<>();
		query.add("steve");query.add("alex");
		System.out.println(trie.displayContacts(names,query));

	
	}
}