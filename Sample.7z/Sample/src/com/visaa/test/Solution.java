/**
 * 
 */
package com.visaa.test;

/**
 * @author RushabhkumarKhandare
 *
 */
public class Solution {
	 public static SinglyLinkedListNode removeNodes(SinglyLinkedListNode listHead, int x) {
	        SinglyLinkedListNode newHead = null;
	        SinglyLinkedListNode newHead2 = null;
	        newHead2 = newHead;
	        SinglyLinkedListNode temp = listHead;
	        
	        while (temp != null) {
	            if (temp.data <= x) {
	            	if(newHead==null){
	            		newHead = new SinglyLinkedListNode(temp.data);
	            		newHead2=newHead;
	            	}
	            	else if (newHead.next == null) {
	                    newHead.next = new SinglyLinkedListNode(temp.data);
	                    newHead=newHead.next;
	                }
	                else newHead.data = temp.data;
	                
	            }
	            temp = temp.next;
	        }
	        return newHead2;
	    }

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		SinglyLinkedListNode listHead2 = new SinglyLinkedListNode(1);
		listHead2.next=new SinglyLinkedListNode(2);
		listHead2.next.next=new SinglyLinkedListNode(3);
		listHead2.next.next.next=new SinglyLinkedListNode(4);
		listHead2.next.next.next.next=new SinglyLinkedListNode(5);
		SinglyLinkedListNode test = removeNodes(listHead2, 3);
		System.out.println(test);
		String t = "abc";
		t = t.substring(1);
		System.out.println(t.substring(0,0));
	}

}

/*
 * For your reference:
 */
class SinglyLinkedListNode {
	int data;
	SinglyLinkedListNode next;
	SinglyLinkedListNode(int n){
		this.data=n;
		this.next=null;
	}
}
