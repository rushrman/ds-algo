/**
 * 
 */
package com.inter20.practise;

import java.util.ArrayList;
import java.util.List;

/**
 * @author RushabhkumarKhandare
 *
 */
public class CoinSumInfinite {
	static public int coinchange(ArrayList<Integer> A, int B) {
		int [] coinsum = new int[B+1];
		coinsum[0]=1;
		for(int i=0;i<A.size();i++){
			for(int j=A.get(i);j<=B;j++){
				coinsum[j]+=coinsum[j-A.get(i)];
			}
		}
		return coinsum[B];
    }
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<Integer> list = new ArrayList<>();
		list.add(1);list.add(2);list.add(3);
		System.out.println(coinchange(list,4));
	}

}
