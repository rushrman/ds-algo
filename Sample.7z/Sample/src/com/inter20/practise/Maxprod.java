/**
 * 
 */
package com.inter20.practise;

import java.util.ArrayList;
import java.util.List;

/**
 * @author RushabhkumarKhandare
 *
 */
public class Maxprod {
	static public int maxProduct(final List<Integer> A) {
		List<Integer> B = A;
		int maxProd = A.get(0);
		int currMaxProd = A.get(0);
		for (int i = 1; i < A.size(); i++) {
			currMaxProd*=A.get(i);
			if(currMaxProd<=0){
				currMaxProd=1;
			}
			if(currMaxProd>maxProd){
				maxProd=currMaxProd;
			}
		}
		return maxProd;
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Integer> list = new ArrayList<>();
		list.add(2);list.add(3);list.add(-2);list.add(4);
		System.out.println(maxProduct(list));
	}

}
