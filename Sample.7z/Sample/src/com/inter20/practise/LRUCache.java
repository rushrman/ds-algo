/**
 * 
 */
package com.inter20.practise;

import java.util.HashMap;

/**
 * @author RushabhkumarKhandare
 *
 */
public class LRUCache {
	static HashMap<Integer, LNode> cache;
	static int maxsize;
	static int count;
	static LNode head;
	static LNode tail;

	LRUCache(int maxsize) {
		cache = new HashMap<>();
		maxsize = maxsize;
		head = new LNode(0,0);
		tail = new LNode(0,0);
		head.next=tail;
		tail.prev=head;
		head.prev=tail.next=null;
		count=0;
	}

	private static void setHead(LNode node) {
			node.next=head.next;
			node.next.prev=node;
			node.prev=head;
			head.next=node;
	}

	private static void remove(LNode n) {
		n.prev.next=n.next;
		n.next.prev=n.prev;
	}

	public static void setData(int key, int value) {
		if (!cache.containsKey(key)) {
			LNode temp = new LNode(key, value);
			cache.put(key, temp);
			if(count<maxsize){
				count++;
			}else{
				cache.remove(tail.prev.data);
				remove(tail.prev);
			}
			setHead(temp);
		} else {
			LNode temp = cache.get(key);
			temp.value = value;
			cache.put(key, temp);
			remove(temp);
			setHead(temp);
		}
	}

	public static int getData(int key) {
		if ((cache.containsKey(key))) {
			LNode temp = cache.get(key);
			remove(temp);
			setHead(temp);
			return cache.get(key).value;
		}
		return -1;
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}

class LNode {
	int data;
	int value;
	LNode prev;
	LNode next;

	LNode(int data, int value) {
		this.data = data;
		this.value = value;
		this.prev = this.next = null;
	}
}
