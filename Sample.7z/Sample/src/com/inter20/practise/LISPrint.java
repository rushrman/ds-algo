/**
 * 
 */
package com.inter20.practise;

import java.util.ArrayList;
import java.util.List;

/**
 * @author RushabhkumarKhandare
 *
 */
public class LISPrint {
	private static int lengoflis(int [] arr){
		List<Integer> lis = new ArrayList<>();
		for(int a : arr){
			if(lis.size()==0||a>lis.get(lis.size()-1)){
				lis.add(a);
			}else {
				int i =0;
				int j=lis.size()-1;
				while(i<j){
					int mid = (i+j)/2;
					if(lis.get(mid)<a){
						i=mid+1;
					}else {
						j=mid;
					}
				}
				lis.add(j, a);
			}
		}
		System.out.println(lis);
		return lis.size();
	}
	private static void printLIS(int[] arr){
		int n = arr.length;	
		int [] LIS = new int[n+1];
		List<ArrayList<Integer>> lisPrint = new ArrayList<ArrayList<Integer>>();
		lisPrint.add(0,new ArrayList<>());
		lisPrint.get(0).add(arr[0]);
		LIS[0]=1;
		for(int i=1;i<n;i++){
			lisPrint.add(i,new ArrayList<>());
			for(int j=0;j<i;j++){
				if(arr[i]>arr[j]&&lisPrint.get(i).size()<lisPrint.get(j).size()+1){
					lisPrint.set(i,lisPrint.get(j));
				}
			}
			lisPrint.get(i).add(arr[i]);
		}
		ArrayList<Integer> max = lisPrint.get(0);
		for(ArrayList<Integer> a :lisPrint){
			if(a.size()>max.size()){
				max=a;
			}
		}
		System.out.println(max);
	}
	public static int lengthOfLIS(int[] nums) {
	    if(nums==null || nums.length==0)
	        return 0;
	 
	    ArrayList<Integer> list = new ArrayList<Integer>(); 
	    ArrayList<Integer> list2 = new ArrayList<Integer>(); 
	    for(int num: nums){
	        if(list.size()==0 || num>list.get(list.size()-1)){
	            list.add(num);
	        }else{
	            int i=0; 
	            int j=list.size()-1;
	 
	            while(i<j){
	                int mid = (i+j)/2;
	                if(list.get(mid) < num){
	                    i=mid+1;
	                }else{
	                    j=mid;
	                }
	            }
	 
	            list.set(j, num);
	        }
	    }
	 
	    return list.size();
	}
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int arr[] = { 3, 2, 6, 4, 5, 1 }; 
		//printLIS(arr);
		System.out.println(lengthOfLIS(arr));
	}

}
