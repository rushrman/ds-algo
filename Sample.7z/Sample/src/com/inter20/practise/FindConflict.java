package com.inter20.practise;

public class FindConflict {
	private static boolean overlapCheck(Interval i, Interval j) {
		if (i.low < j.low && j.low > i.high) {
			return false;
		}
		return true;
	}

	private static Node insert(Node root, Interval i) {
		if (root == null) {
			return new Node(i);
		}
		int n = root.i.low;
		if (n < i.low)
			return insert(root.left, i);
		else if (n > i.low)
			return insert(root.right, i);

		if (root.max < i.high)
			root.max = i.high;
		return root;
	}

	private static Interval overlapSearch(Node root, Interval i) {
		if (root == null)
			return null;
		Interval j = root.i;
		if (overlapCheck(i, j))
			return j;
		if (root.left != null && i.low <= root.max)
			return overlapSearch(root.left, i);
		return overlapSearch(root.right, i);
	}
	public static void printConflict(Interval[] intervals){
		Node root=null;
		insert(root, intervals[0]);
		for(int i=0;i<intervals.length;i++){
			Interval res = overlapSearch(root, intervals[i]);
			if(res!=null){
				System.out.println("This is conflict between"+"start"+intervals[i].low+"high"+intervals[i].high);
				System.out.println("and"+"start"+res.low+"high"+res.high);
			}
		}
	}
	public static void main(String[] args) {
		// Let us create interval tree shown in above figure 
	    /*Interval appt[] = { {1, 5}, {3, 7}, {2, 6}, {10, 15}, 
	                        {5, 6}, {4, 100}}; 
*/
	}

}

class Node {
	Interval i;
	int max;
	Node left, right;

	Node(Interval i) {
		this.i = i;
		this.left = this.right = null;
		max = i.high;
	}
}

class Interval {
	int low, high;
	public Interval(int i,int j) {
		this.low=i;
		this.high=j;
	}
}
