/**
 * 
 */
package com.inter20.practise;

import java.util.List;

/**
 * @author RushabhkumarKhandare
 *
 */
public class LengthOfBotnicSubSec {
	/*
	 * Length of longest bitonic subsequence
	 */
	public static int lenOfBitonicSubSec(int[] a) {
		// Calculate LIS
		int[] LIS = new int[a.length];
		for (int i = 0; i < LIS.length; i++) {
			LIS[i] = 1;
		}
		for (int i = 1; i < a.length; i++) {
			for (int j = 0; j < i; j++) {
				if (a[i] > a[j] && LIS[i] < LIS[j] + 1) {
					LIS[i] = LIS[j] + 1;
				}
			}
		}
		for (int i = 0; i < LIS.length; i++) {
			System.out.print(LIS[i]);
		}
		System.out.println(" ");
		// Calculate DIS
		int[] DIS = new int[a.length];
		for (int i = 0; i < LIS.length; i++) {
			DIS[i] = 1;
		}
		for (int i = a.length - 2; i >= 0; i--) {
			for (int j = a.length - 1; j > i; j--) {
				if (a[i] > a[j] && DIS[i] < DIS[j] + 1) {
					DIS[i] = DIS[j] + 1;
				}
			}
		}
		for (int i = 0; i < DIS.length; i++) {
			System.out.print(DIS[i]);
		}
		System.out.println(DIS);
		int result = LIS[0] + DIS[0]-1;
		for (int i = 1; i < LIS.length; i++) {
			if(result<LIS[i]+DIS[i]-1){
				result=LIS[i]+DIS[i]-1;
			}
		}
		return result;
	}
	public int longestSubsequenceLength(final List<Integer> A) {
		List<Integer> B = A;
		int[]a= new int[B.size()];
		for(int i=0;i<a.length;i++){
			a[i]=B.get(i);
		}
		return lenOfBitonicSubSec(a);
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int[] a= {0, 8, 4, 12, 2, 10, 6, 14, 1, 9, 5, 
                13, 3, 11, 7, 15};
		System.out.println(lenOfBitonicSubSec(a));

	}

}
