/**
 * 
 */
package com.inter20.practise;

import java.util.HashSet;

/**
 * @author RushabhkumarKhandare
 *
 */
public class LCSprint {
	static int [][] lcs;
	private static HashSet<String> printAllLcs(String x,String y,int m,int n){
		HashSet<String> set = new HashSet<>();
		if(m==0||n==0){
			set.add("");
			return set;
		}
		if(x.charAt(m-1)==y.charAt(n-1)){
			HashSet<String> temp=printAllLcs(x,y,m-1,n-1);
			for(String str : temp)
			set.add(str+x.charAt(m-1));
		}
		else{
			if(lcs[m-1][n]>=lcs[m][n-1]){
				set=printAllLcs(x,y,m-1,n);
			}
			if(lcs[m-1][n]<=lcs[m][n-1]){
			HashSet<String> s = printAllLcs(x,y,m,n-1);
			for(String str:s)
				set.add(str);
			}
		}
		return set;
	}
	/*
	 * Print LCS
	 * */
	private static void printLCS(String x,String y,int m,int n){
		lcs = new int[m+1][n+1];
		for(int i=0;i<=m;i++){
			for(int j=0;j<=n;j++){
				if(i==0||j==0)
				 lcs[i][j]=0;
				else if(x.charAt(i-1)==y.charAt(j-1))
					lcs[i][j]=lcs[i-1][j-1]+1;
				else lcs[i][j]=Math.max(lcs[i-1][j], lcs[i][j-1]);
			}
		}
		int index=lcs[m][n];
		int temp=index;
		char[] lcsr= new char[index+1];
		lcsr[index]=' ';
		int i=m,j=n;
		while(i>0&&j>0){
			if(x.charAt(i-1)==y.charAt(j-1)){
				lcsr[index-1]=x.charAt(i-1);
				index--;
				i--;
				j--;
			}
			else if(lcs[i-1][j]>=lcs[i][j-1]){
				i--;
			}
			else j--;
		}
		for(int k=0;k<=temp;k++){
			System.out.print(lcsr[k]);
		}
	}
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		printLCS("ABCDGH","AEDFHR",6,6);
		HashSet<String> s = printAllLcs("AGTGATG","GTTAG",7,5);
		System.out.println(s);
	}

}
