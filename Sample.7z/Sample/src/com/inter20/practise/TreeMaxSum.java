/**
 * 
 */
package com.inter20.practise;

/**
 * @author RushabhkumarKhandare
 *
 */
public class TreeMaxSum {
	public static int maxsumPath(TreeNode root) {
		Res res = new Res();
		res.val = Integer.MIN_VALUE;
		maxsumPathUtil(root, res);
		return res.val;
	}

	private static int maxsumPathUtil(TreeNode root, Res res) {
		if (root == null) {
			return 0;
		}
		int l = maxsumPathUtil(root.left, res);
		int r = maxsumPathUtil(root.right, res);

		int max_single = Math.max(Math.max(l, r) + root.data, root.data);
		int max_top = Math.max(max_single, l + r + root.data);
		res.val = Math.max(res.val, max_top);
		return max_single;
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		TreeNode root = new TreeNode(10);
		root.left=new TreeNode(2);
		root.right=new TreeNode(10);
		root.left.left=new TreeNode(20);
		root.left.right=new TreeNode(1);
		root.right.right=new TreeNode(-25);
		root.right.right.left=new TreeNode(3);
		root.right.right.right=new TreeNode(4);
		
		System.out.println("maximum path sum is : " + 
				maxsumPath(root)); 
	}

}

class Res {
	public int val;
}

class TreeNode {
	int data;
	TreeNode right;
	TreeNode left;

	TreeNode(int data) {
		this.data = data;
		this.left = this.right = null;
	}
}
