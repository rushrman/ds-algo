/**
 * 
 */
package com.inter20.practise;

import java.util.ArrayList;

/**
 * @author RushabhkumarKhandare
 *
 */
public class PrintAllSubsetSum {
	static boolean[][] dp;

	private static void printAllSubsets(int[] a, int sum) {
		dp = new boolean[a.length][sum + 1];
		for (int i = 0; i < a.length; i++) {
			dp[i][0] = true;
		}
		if (a[0] <= sum)
			dp[0][a[0]] = true;
		for (int i = 1; i < a.length; i++) {
			for (int j = 0; j < sum + 1; j++) {
				dp[i][j] = (a[i] <= j) ? dp[i - 1][j] || dp[i - 1][j - a[i]] : dp[i - 1][j];
			}
		}
		if (!dp[a.length - 1][sum]) {
			System.out.println("No subset sum");
			return;
		}
		ArrayList<Integer> p = new ArrayList<>();
		printAllSubsetsRec(a, a.length - 1, sum, p);
	}

	private static void printAllSubsetsRec(int[] a, int i, int sum, ArrayList<Integer> p) {
		if (i == 0 && sum != 0 && dp[0][a[0]]) {
			p.add(a[i]);
			System.out.println(p);
			p.clear();
			return;
		}
		if (i == 0 && sum == -0) {
			System.out.println(p);
			p.clear();
			return;
		}
		if (dp[i - 1][sum]) {
			ArrayList<Integer> b = new ArrayList<>();
			b.addAll(p);
			printAllSubsetsRec(a, i - 1, sum, b);
		}
		if (sum >= a[i] && dp[i - 1][sum - a[i]]) {
			p.add(a[i]);
			printAllSubsetsRec(a, i - 1, sum - a[i], p);
		}

	}

	public static boolean subSetSumBool(int[] subset, int sum, int n) {
		if (n <= 0 && sum != 0)
			return false;
		if (sum == 0)
			return true;
		if (subset[n - 1] > sum)
			return subSetSumBool(subset, sum, n - 1);
		return subSetSumBool(subset, sum - subset[n - 1], n - 1);
	}

	public static boolean subSetSumdp(int[] subset, int sum, int n) {
		boolean [][] dp = new boolean[subset.length+1][sum+1];
		for(int i =0;i<=subset.length;i++){
			dp[i][0]=true;
		}
		for(int i =1;i<=sum;i++){
			dp[0][i]=false;;
		}
		for(int i =1;i<=subset.length;i++){
			for(int j=1;j<=sum;j++){
				dp[i][j]=dp[i][j-1];
				if(subset[i-1]<=j){
					dp[i][j]=dp[i-1][j-subset[i-1]];
				}
			}
		}
		return dp[n][sum];
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int arr[] = { 6, 8, 5, 4, 7 };
		int n = arr.length;
		int sum = 2;
		System.out.print(subSetSumdp(arr, sum, n));
	}

}
