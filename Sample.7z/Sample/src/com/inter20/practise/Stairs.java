/**
 * 
 */
package com.inter20.practise;

/**
 * @author RushabhkumarKhandare
 *
 */
public class Stairs {
	public static int stairs(int a,int m){
		int[] res = new int[a+1];
		res[0]=1;
		res[1]=1;
		for(int i =2;i<a;i++){
			res[i]=0;
			for(int j=1;j<=m&&j<=i;j++){
				res[i]+=res[i-j];	
			}
		}
		return res[res.length-2];
	}
	public int climbStairs(int A) {
		return stairs(A,2);
	}
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a =4;
System.out.println(stairs(a+1,2));
	}

}
