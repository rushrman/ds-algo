/**
 * 
 */
package com.inter20.practise;

import java.util.HashMap;

/**
 * @author RushabhkumarKhandare
 *
 */
public class AutoComplete {
	public static void insert(TrieNode root, String key) {
		if (root == null)
			root = new TrieNode();
		TrieNode itr = root;
		for (int level = 0; level < key.length(); level++) {
			char index = key.charAt(level);
			TrieNode temp = itr.child.get(Character.valueOf(index));
			if (temp == null) {
				temp = new TrieNode();
				itr.child.put(Character.valueOf(index), temp);
			}
			itr = temp;
			if (level == key.length() - 1)
				itr.islast = true;
		}
	}
	public static boolean search(TrieNode root, String key) {
		if (root == null)
			return false;
		TrieNode itr = root;
		for (int level = 0; level < key.length(); level++) {
			char index = key.charAt(level);
			TrieNode temp = itr.child.get(Character.valueOf(index));
			if (temp == null) {
				return false;
			}
			itr = temp;
		}
		return (itr!=null&&itr.islast);
	}
	public static int printAutoSearch(TrieNode root,String query){
		TrieNode pCrawl=root;
		for(int i=0;i<query.length();i++){
			if(pCrawl.child.get(query.charAt(i))==null)
				return 0;
			pCrawl=pCrawl.child.get(query.charAt(i));
		}
		boolean isword=pCrawl.islast;
		boolean islast=isLastNode(pCrawl);
		if(isword&&islast){
			System.out.println(query);
			return -1;
		}
		if(!islast){
			String prefix=query;
			suggestionsRec(root,prefix);
			return 1;
		}
		return 0;
	}

	private static void suggestionsRec(TrieNode root, String prefix) {
		if(root.islast){
			System.out.println(prefix);
		}
		if(isLastNode(root))
			return;
		for(char i='a';i<='z';i++){
			if(root.child.get(i)!=null){
				prefix=prefix+i;
				suggestionsRec(root.child.get(i), prefix);
			}
		}
		
	}
	private static boolean isLastNode(TrieNode pCrawl) {
		for(char i='a';i<='z';i++){
			if(pCrawl.child.get(i)!=null)
				return true;
		}
		return false;
	}
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}

class TrieNode {
	boolean islast;
	HashMap<Character, TrieNode> child;

	TrieNode() {
		this.islast = false;
		this.child = new HashMap<>();
		for (char i = 'a'; i <= 'z'; i++) {
			this.child.put(Character.valueOf(i), null);
		}
	}
}
