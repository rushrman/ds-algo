/**
 * 
 */
package com.inter20.practise;

import java.util.ArrayList;

/**
 * @author RushabhkumarKhandare
 *
 */
public class MinJumps {
	static ArrayList<Integer> list = new ArrayList<>();
	private static int minjumps(int[] arr) {
		int minjumps = 1;
		int steps = arr[0];
		int maxreach = arr[0];
		for (int i = 1; i < arr.length; i++) {
			if(arr[i]==0)
				return 0;
			if (i == arr.length - 1)
				return minjumps;
			maxreach = Math.max(maxreach, i + arr[i]);
			steps--;
			if (steps == 0) {
				minjumps++;
				
				steps = maxreach - i;
				list.add(arr[i]);
			}
		}
		return minjumps;
	}
	private static int canJumps(int[] arr) {
		int minjumps = 1;
		int steps = arr[0];
		int maxreach = arr[0];
		if(maxreach==0)
			return 0;
		for (int i = 1; i < arr.length; i++) {
			if (i == arr.length - 1)
				return 1;
			maxreach = Math.max(maxreach, i + arr[i]);
			steps--;
			if (steps == 0) {
				minjumps++;
				
				steps = maxreach - i;
				list.add(arr[i]);
			}
		}
		return 0;
	}
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int[] arr = {1, 3, 5, 8, 9, 2, 6, 7, 6, 8, 9};
		int[] a = {-2, 1, 2, 5};
		System.out.println(minjumps(a));
		System.out.println(list);
	}

}
