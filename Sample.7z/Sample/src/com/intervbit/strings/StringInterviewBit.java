/**
 * 
 */
package com.intervbit.strings;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

/**
 * @author RushabhkumarKhandare
 *
 */
public class StringInterviewBit {

	boolean isValidchar(char x) {
		if ((x >= 'A' && x <= 'Z') || (x <= 'z' && x >= 'a') || (x <= '9' && x >= '0'))
			return true;
		else
			return false;
	}

	public int isPalindrome(String A) {
		int i = 0, j = A.length() - 1;
		int result = 1;
		if (A.length() == 0)
			return result;
		if (A.length() == 1)
			return 1;
		while (i < j && j > i) {
			char m = A.charAt(i);
			char n = A.charAt(j);
			if (isValidchar(m) && isValidchar(n)) {
				if (String.valueOf(m).toLowerCase().equals(String.valueOf(n).toLowerCase())) {
					i++;
					j--;
				} else
					return 0;
			} else if (isValidchar(m) && !isValidchar(n)) {
				j--;
			} else if (!isValidchar(m) && isValidchar(n)) {
				i++;
			} else {
				i++;
				j--;
			}
		}
		return result;
	}

	public static String longestCommonPrefix(ArrayList<String> A) {
		int min = 0;
		String minS = "";
		for (String a : A) {
			if (a.length() > min) {
				min = a.length();
				minS = a;
			}
		}
		int i = 0;
		while (i < min) {
			char c = minS.charAt(i);
			for (String a : A) {
				if (i < a.length() && a.charAt(i) == c)
					continue;
				else {
					if (i > 0) {
						return minS.substring(0, i);
					}
				}
			}
			i++;
		}
		return minS.substring(0, i - 1);
	}

	boolean isValidcharforAmazing(char x) {
		if (x == 'a' || x == 'e' || x == 'i' || x == 'o' || x == 'u' || x == 'A' || x == 'E' || x == 'I' || x == 'O'
				|| x == 'U')
			return true;
		else
			return false;
	}

	public int amazingSubstring(String A) {
		int count = 0;
		for (int i = 0; i < A.length(); i++) {
			if (isValidcharforAmazing(A.charAt(i))) {
				count += A.substring(i, A.length()).length();
			}
		}
		return count;
	}

	public String longestPalindrome(String A) {
		int maxlength = 0;
		int start = 0, end = 0, s = 0, e = 0;
		for (int i = 0; i < A.length(); i++) {
			start = i;
			end = i + 1;
			while (start >= 0 && end < A.length() && A.charAt(start) == A.charAt(end)) {
				if (maxlength < end - start + 1) {
					maxlength = end - start + 1;
					s = start;
					e = end;
				}
				start--;
				end++;
			}
			start = i - 1;
			end = i + 1;
			while (start >= 0 && end < A.length() && A.charAt(start) == A.charAt(end)) {
				if (maxlength < end - start + 1) {
					maxlength = end - start + 1;
					s = start;
					e = end;
				}
				start--;
				end++;
			}
		}
		return A.substring(s, e + 1);
	}

	boolean isPalidromePure(String str, int start, int end) {
		if (start > end)
			return false;
		if (str.length() == 1 || str.length() == 0 || str == null)
			return true;
		if (str.length() == 2 && str.charAt(0) == str.charAt(1))
			return true;
		while (start < end) {
			if (str.charAt(start) != str.charAt(end))
				return false;
			else {
				start++;
				end--;
			}
		}
		return true;
	}

	public int minCharTomakeStringPalim(String A) {
		int maxlen = 0;
		int flag = 0;
		while (A.length() > 0) {
			if (isPalidromePure(A, 0, A.length() - 1)) {
				flag = 1;
				break;
			} else {
				maxlen++;
				A = A.substring(0, A.length() - 1);
			}
		}
		if (flag == 1)
			return maxlen;
		else
			return 0;
	}

	public int compareVersion(String A, String B) {
		A = A.replace(".", "");
		B = B.replace(".", "");
		if (A.length() > B.length())
			return 1;
		Integer a = Integer.valueOf(A);
		Integer b = Integer.valueOf(B);
		if (a > b)
			return 1;
		else if (a == b)
			return 0;
		else
			return -1;
	}

	public void printPermute(String input, String ans) {
		if (input.length() == 0) {
			System.out.println(ans);
			return;
		}
		boolean[] repeat = new boolean[26];
		for (int i = 0; i < input.length(); i++) {
			char ch = input.charAt(i);
			String ros = input.substring(0, i) + input.substring(i + 1);
			if (!repeat[ch - 'a'])
				printPermute(ros, ans + ch);

			repeat[ch - 'a'] = true;
		}
	}

	public void searchAnagramSubstring(String pat, String text) {
		char countP[] = new char[256];
		char countTW[] = new char[256];
		int M = pat.length();
		for (int i = 0; i < M; i++) {
			countP[pat.charAt(i)]++;
			countTW[text.charAt(i)]++;
		}
		for (int i = M; i < text.length(); i++) {
			if (compare(countP, countTW)) {
				System.out.println(i - M);
			}
			(countTW[text.charAt(i)])++;
			(countTW[text.charAt(i - M)])--;
		}
		if (compare(countP, countTW)) {
			System.out.println(text.length() - M);
		}
	}

	private boolean compare(char[] countP, char[] countTW) {
		for (int i = 0; i < 256; i++) {
			if (countP[i] != countTW[i])
				return false;
		}
		return true;
	}

	public int solve(ArrayList<String> A) {
		Set<Character> set = new HashSet<>();
		String output = "";
		for (String s : A) {
			for (int i = 0; i < s.length(); i++) {
				if (!set.contains(s.charAt(i))) {
					set.add(s.charAt(i));
					output += s.charAt(i);
				}
			}
		}
		return output.length();
	}
	 public boolean ispalin(String input, int begin, int end) {
	        while (begin < end) {
	            if (input.charAt(begin) != input.charAt(end))
	                return false;
	            begin++;
	            end--;
	        }
	        return true;
	}
	 
	 public void printpart(String input, String output, int begin, int end) {
	        if (begin == end) {
	            System.out.println(output);
	            return;
	        }
	        int n = input.length();
	        String delimiter = "-";
	        for (int i = begin; i < end; i++) {
	            if (ispalin(input, begin, i)) {
	                if (i+1 == n) {
	                    delimiter = "";
	                }
	                printpart(input, output + input.substring(begin, i+1) + delimiter, i + 1, end);
	            }
	        }
	    }

	public static void main(String[] args) {
		StringInterviewBit it = new StringInterviewBit();
		// System.out.println(it.isPalindrome("'"));
		ArrayList<String> list = new ArrayList<>();
		list.add("cpsklryvmcp");
		list.add("nbpbwllsrehfmx");
		list.add("kecwitrsglre");
		list.add("kecwitrsglre");
		it.printpart("banana", "", 0, 6);
		System.out.println();
	}

}
